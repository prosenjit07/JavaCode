/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab_task3;
import java.util.Scanner;

public class Lab1 {
    public static void main(String[] args) {
        Scanner obj = new Scanner(System.in);
        int n;
        System.out.println("How many Studetns’ CGPA you want to insert?");
        n = obj.nextInt();
        double[]arr = new double[n];
        for(int i= 0; i<n; i++){
            System.out.println("Enter"+(i+1)+" persion cgpa: ");
            arr[i]= obj.nextDouble();
        }
        for(int i=0; i<n; i++){
            System.out.print(arr[i]+" ");
        }
        double max = arr[0];
        double min =arr[0];
        for(int i=0; i<n; i++){
            if(max<arr[i]){
                max = arr[i];
            }  
        }
        for(int i=0; i<n; i++){
            if(min>arr[i]){
                min = arr[i];
            }
        }
        {
                System.out.println("\nMaximum value in the array is : "+max);
                System.out.println("\nMinumum value in the array is : "+min);
        }
    }
}


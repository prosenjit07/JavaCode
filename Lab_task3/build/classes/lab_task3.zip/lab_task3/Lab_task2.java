package lab_task3;


import java.util.Scanner;
public class Lab_task3{
    public static void main(String[] args) {
        Scanner obj_name = new Scanner(System.in);
        int n;
        System.out.println("How many Numbers you want to insert?");
        n = obj_name.nextInt();
        int[]array=new int[n];
        for( int i=0; i<n; i++){
            System.out.println("Enter "+(i+1)+ " number element: ");
            array[i] = obj_name.nextInt();
        }
        for(int i=0; i<n; i++){
            System.out.print(array[i]+" ");
        }
        int find;
        System.out.println("\nEnter which number you want to search? ");
        find = obj_name.nextInt();
        for(int i=0; i<n; i++){
            if(array[i] == find)
            {
                System.out.println(find+" is present at location "+(i+1));
                break;
            }
            else if(array[i] != find){
                System.out.println(find+ " not found in the Array");
                break;
            }
         
          
        }
            
     
    }
}

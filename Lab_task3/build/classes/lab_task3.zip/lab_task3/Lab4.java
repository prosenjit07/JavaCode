/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab_task3;

import java.util.Scanner;
import java.lang.Math;

public class Lab4{
    public static void main(String[] args) {
        Scanner obj = new Scanner(System.in);
        int n;
        System.out.println("Enter a number?");
        n = obj.nextInt();
        double a,b;
        a = Math.pow(2, 0);
        b = Math.pow(2, n);
        
        System.out.println("Value of 2^0 = "+a);
        System.out.println("Value of 2^n = "+b);
    }
}
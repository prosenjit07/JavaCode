/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package student2;
public class Student2 {

     private String name;
     private int id;
     private double cgpa;

     //Setter methods
    public void setName(String name) {
        this.name = name;
    }
     // Getter methods 
    public String getName() {
        return this.name;
    }
//Setter methods
    public void setId(int a) {
        this.id = a;
    }
 // Getter methods 
    public int getId() {
        return this.id;
    }

    public void setCgpa(double c) {
        this.cgpa = c;
    }

    public double getCgpa() {
        return this.cgpa;
    }
/*
    public void insertName(String name, int id, double cgpa) {
        this.name = name;
        this.id = id;
        this.cgpa = cgpa;
//display method
    public void display() {

        System.out.println("Name of the student = " + this.name);
        System.out.println("ID of the student= " + this.id);
        System.out.println("cgpa of the student = " + this.cgpa);
    }    
*/
}

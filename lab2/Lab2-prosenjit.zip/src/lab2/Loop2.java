 
class Loop2 {
  public static void main(String[] args) {
    int x;
     for(x=1; x<=100; x++){
         if(x%3!=0 && x%6!=0 && x!=10 && x!=20 &&x!=30 && x!=40){
             System.out.println("output" + x); 
         }
     }
  }
}
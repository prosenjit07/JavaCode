package Problem6;

import java.util.Scanner;

public class Problem6 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.println("Enter mark marks");
		double mark = scan.nextDouble();

		if(mark >= 90){
			System.out.println("Outstanding: Grade A");
		}else if(mark < 90 && mark >= 80){
			System.out.println("Excellent Good: Grade B");
		}else if(mark < 80 && mark >= 70){
			System.out.println("Good: Grade C");
		}else if(mark < 70 && mark >= 60){
			System.out.println("Satisfactory: Grade D");
		}else if(mark < 60 && mark >= 50){
			System.out.println("Work Hard: Grade E");
		}else if(mark < 50 && mark >= 40){
			System.out.println("Passed: Grade F");
		}else {
			System.out.println("Failed!");
		}
	}

}